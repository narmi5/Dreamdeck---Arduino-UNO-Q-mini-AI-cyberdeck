# SPDX-License-Identifier: MPL-2.0

import os
import re
import time

from typing import Any

from arduino.app_bricks.llm import LargeLanguageModel
from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import *

from prompts import load_system_prompt


# ============================================================
# INITIALIZATION
# ============================================================

print("[INFO] Initializing local AI...")

llm = LargeLanguageModel(
    system_prompt=load_system_prompt()
)

ui = WebUI()

ai_active = True


# ============================================================
# AI CHAT
# ============================================================

MAX_PAIRS = 2

chat_history: list[dict[str, str]] = []


def build_context_prompt(user_input: str) -> str:

    try:
        temperature = Bridge.call(
            "get_temperature"
        )
    except Exception:
        temperature = "unknown"

    context_lines = [
        f"System context - Real-time temperature: {temperature}"
    ]

    if chat_history:

        context_lines.append(
            "Conversation history:"
        )

        for msg in chat_history:

            if msg["role"] == "user":

                context_lines.append(
                    f"User: {msg['content']}"
                )

            else:

                context_lines.append(
                    f"AI: {msg['content']}"
                )

    context_lines.append(
        f"User: {user_input}\nAI:"
    )

    return "\n".join(context_lines)


def clean_response(
    text: str,
    user_prompt: str
) -> str:

    text = text.strip()

    escaped_prompt = re.escape(
        user_prompt
    )

    text = re.sub(
        rf'^(?:User:)?\s*{escaped_prompt}[\s\?\!:\.]*',
        '',
        text,
        flags=re.IGNORECASE
    ).strip()

    text = re.sub(
        r'^(AI|Assistant|Model|Response|Gemma):\s*',
        '',
        text,
        flags=re.IGNORECASE
    )

    text = re.split(
        r'\n?(?:User|User asked|AI|Assistant):',
        text,
        flags=re.IGNORECASE
    )[0]

    return text.replace(
        "\n",
        " "
    ).strip()


def genera_risposta_cyberdeck(
    data: dict[str, Any]
) -> dict[str, str]:

    global chat_history

    try:

        prompt = data.get(
            "prompt",
            ""
        )

        if not prompt:

            return {
                "text": "Prompt vuoto"
            }

        print(
            f"\n[CYBERDECK AI] {prompt}"
        )


        # ----------------------------------------
        # TEMPERATURE
        # ----------------------------------------

        if "TEMPERATURE" in prompt.upper():

            try:

                temp = Bridge.call(
                    "get_temperature"
                )

                return {
                    "text":
                    f"Current temperature is {temp} degrees Celsius"
                }

            except Exception as e:

                return {
                    "text":
                    f"Temperature error: {e}"
                }


        # ----------------------------------------
        # MORSE
        # ----------------------------------------

        if prompt.upper().startswith(
            "MORSE "
        ):

            try:

                sub_prompt = prompt[
                    6:
                ].strip()

                output = morse_translate(
                    sub_prompt
                )

                return {
                    "text":
                    "Morse translation: " +
                    output
                }

            except Exception:

                return {
                    "text":
                    "Failed to translate Morse."
                }


        # ----------------------------------------
        # NORMAL AI
        # ----------------------------------------

        full_prompt = build_context_prompt(
            prompt
        )

        risposta_raw = ""

        for resp in llm.chat_stream(
            full_prompt
        ):

            risposta_raw += resp

        risposta_pulita = clean_response(
            risposta_raw,
            prompt
        )

        print(
            f"[LOCAL AI] {risposta_pulita}"
        )


        # ----------------------------------------
        # SAVE CHAT HISTORY
        # ----------------------------------------

        chat_history.append(
            {
                "role": "user",
                "content": prompt
            }
        )

        chat_history.append(
            {
                "role": "assistant",
                "content": risposta_pulita
            }
        )

        if len(chat_history) > (
            MAX_PAIRS * 2
        ):

            chat_history = chat_history[
                -(MAX_PAIRS * 2):
            ]


        return {
            "text":
            risposta_pulita
        }


    except Exception as e:

        print(
            f"[AI ERROR] {e}"
        )

        return {
            "text":
            f"Internal error: {str(e)}"
        }


# ============================================================
# MORSE
# ============================================================

MORSE_A_LETTERA = {

    ".-": "A",
    "-...": "B",
    "-.-.": "C",
    "-..": "D",
    ".": "E",
    "..-.": "F",
    "--.": "G",
    "....": "H",
    "..": "I",
    ".---": "J",
    "-.-": "K",
    ".-..": "L",
    "--": "M",
    "-.": "N",
    "---": "O",
    ".--.": "P",
    "--.-": "Q",
    ".-.": "R",
    "...": "S",
    "-": "T",
    "..-": "U",
    "...-": "V",
    ".--": "W",
    "-..-": "X",
    "-.--": "Y",
    "--..": "Z",
    "/": " ",

    "-----": "0",
    ".----": "1",
    "..---": "2",
    "...--": "3",
    "....-": "4",
    ".....": "5",
    "-....": "6",
    "--...": "7",
    "---..": "8",
    "----.": "9"
}


LETTERA_A_MORSE = {

    "A": ".-",
    "B": "-...",
    "C": "-.-.",
    "D": "-..",
    "E": ".",
    "F": "..-.",
    "G": "--.",
    "H": "....",
    "I": "..",
    "J": ".---",
    "K": "-.-",
    "L": ".-..",
    "M": "--",
    "N": "-.",
    "O": "---",
    "P": ".--.",
    "Q": "--.-",
    "R": ".-.",
    "S": "...",
    "T": "-",
    "U": "..-",
    "V": "...-",
    "W": ".--",
    "X": "-..-",
    "Y": "-.--",
    "Z": "--..",

    " ": "/",

    "0": "-----",
    "1": ".----",
    "2": "..---",
    "3": "...--",
    "4": "....-",
    "5": ".....",
    "6": "-....",
    "7": "--...",
    "8": "---..",
    "9": "----."
}


def morse_translate(
    sentence: str
) -> str:

    sentence = sentence.upper()

    if is_sentence_morse(
        sentence
    ):

        output = ""

        for combination in sentence.split():

            output += MORSE_A_LETTERA.get(
                combination,
                "?"
            )

        return output.lower()


    output = ""

    for char in sentence:

        if char in LETTERA_A_MORSE:

            output += (
                LETTERA_A_MORSE[char] +
                " "
            )

    blink_morse(
        output
    )

    return output.lower()


def is_sentence_morse(
    sentence: str
) -> bool:

    for char in sentence:

        if "A" <= char <= "Z":

            return False

    return True


def blink_morse(
    sentence: str
):

    for char in sentence:

        if char == ".":

            Bridge.call(
                "led",
                True
            )

            time.sleep(0.05)

            Bridge.call(
                "led",
                False
            )

        elif char == "-":

            Bridge.call(
                "led",
                True
            )

            time.sleep(0.2)

            Bridge.call(
                "led",
                False
            )

        elif char == " ":

            Bridge.call(
                "led",
                False
            )

            time.sleep(0.35)

        elif char == "/":

            Bridge.call(
                "led",
                False
            )

            time.sleep(1)

        time.sleep(0.2)


# ============================================================
# SYSTEM INFORMATION
# ============================================================

def read_cpu_usage():

    try:

        with open(
            "/proc/loadavg",
            "r"
        ) as f:

            load = float(
                f.read().split()[0]
            )

        # Load average is not technically CPU percentage.
        # Convert it to a rough percentage based on CPU count.

        cpu_count = os.cpu_count() or 1

        percentage = (
            load / cpu_count
        ) * 100

        return round(
            percentage,
            1
        )

    except Exception:

        return -1


def read_memory_usage():

    try:

        mem_total = 0
        mem_available = 0

        with open(
            "/proc/meminfo",
            "r"
        ) as f:

            for line in f:

                if line.startswith(
                    "MemTotal:"
                ):

                    mem_total = int(
                        line.split()[1]
                    )

                elif line.startswith(
                    "MemAvailable:"
                ):

                    mem_available = int(
                        line.split()[1]
                    )

        if mem_total == 0:

            return -1

        used = (
            mem_total -
            mem_available
        )

        return round(
            (used / mem_total) * 100
        )

    except Exception:

        return -1


def read_uptime():

    try:

        with open(
            "/proc/uptime",
            "r"
        ) as f:

            seconds = int(
                float(
                    f.read().split()[0]
                )
            )

        days = seconds // 86400

        seconds %= 86400

        hours = seconds // 3600

        seconds %= 3600

        minutes = seconds // 60

        seconds %= 60

        return (
            f"{days}d "
            f"{hours:02d}:"
            f"{minutes:02d}:"
            f"{seconds:02d}"
        )

    except Exception:

        return "unknown"


def get_system_status(
    data: dict[str, Any]
) -> dict[str, Any]:

    return {

        "cpu":
        read_cpu_usage(),

        "ram":
        read_memory_usage(),

        "uptime":
        read_uptime(),

        "ai":
        ai_active
    }


# ============================================================
# SENSOR API
# ============================================================

def get_sensors(
    data: dict[str, Any]
) -> dict[str, Any]:

    try:

        temperature = Bridge.call(
            "get_temperature"
        )

    except Exception as e:

        print(
            f"[SENSOR ERROR] Temperature: {e}"
        )

        temperature = "N/A"


    try:

        humidity = Bridge.call(
            "get_humidity"
        )

    except Exception as e:

        print(
            f"[SENSOR ERROR] Humidity: {e}"
        )

        humidity = "N/A"


    return {

        "temperature":
        temperature,

        "humidity":
        humidity
    }


# ============================================================
# GPIO API
# ============================================================

def gpio_command(
    data: dict[str, Any]
) -> dict[str, Any]:

    action = data.get(
        "action",
        ""
    )


    if action == "led":

        state = bool(
            data.get(
                "state",
                False
            )
        )

        try:

            Bridge.call(
                "led",
                state
            )

            return {
                "success": True,
                "led": state
            }

        except Exception as e:

            return {
                "success": False,
                "error": str(e)
            }


    return {

        "success": False,

        "error":
        "Unknown GPIO action"
    }

def buzzer_command(
    data: dict[str, Any]
) -> dict[str, Any]:

    try:

        frequency = int(
            data.get("frequency", 0)
        )

        duration = int(
            data.get("duration", 200)
        )

        if frequency <= 0:
            return {
                "error": "Invalid frequency"
            }

        if duration <= 0 or duration > 2000:
            duration = 200

        Bridge.notify(
            "buzzer",
            frequency,
            duration
        )

        return {
            "status": "ok"
        }

    except Exception as e:

        return {
            "error": str(e)
        }
        
# ============================================================
# NETWORK API
# ============================================================

def get_network_status(
    data: dict[str, Any]
) -> dict[str, Any]:

    # The UNO Q is currently acting as the
    # DreamDeck server at this known address.

    return {

        "ip":
        "10.42.0.1",

        "server":
        "online",

        "port":
        7000
    }


# ============================================================
# TERMINAL
# ============================================================

ALLOWED_COMMANDS = {

    "ls":
        "ls",

    "pwd":
        "pwd",

    "whoami":
        "whoami",

    "uname":
        "uname -a",

    "date":
        "date",

    "uptime":
        "uptime",

    "df":
        "df -h",

    "free":
        "free -h",

    "hostname":
        "hostname",

    "ip":
        "ip addr",

    "neofetch":
        "uname -a && free -h && uptime",

}


def terminal_command(
    data: dict[str, Any]
) -> dict[str, Any]:

    command = data.get(
        "command",
        ""
    ).strip().lower()


    if not command:

        return {
            "output":
            "No command."
        }


    if command not in ALLOWED_COMMANDS:

        return {

            "output":
            "Command not allowed."
        }


    actual_command = (
        ALLOWED_COMMANDS[
            command
        ]
    )


    try:

        pipe = os.popen(
            actual_command
        )

        output = pipe.read()

        pipe.close()


        if len(output) > 1200:

            output = output[
                :1200
            ] + "\n..."


        return {

            "output":
            output
        }


    except Exception as e:

        return {

            "output":
            f"Terminal error: {e}"
        }


# ============================================================
# SHUTDOWN
# ============================================================

def spegni_sistema(
    data: dict[str, Any]
) -> dict[str, str]:

    global ai_active

    print(
        "[SYSTEM] Shutdown requested."
    )

    ai_active = False

    try:

        Bridge.call(
            "ai_isactive",
            False
        )

    except Exception:

        pass


    # Intentionally terminate the UNO Q application.
    # This does NOT power off the physical board.

    os._exit(0)


# ============================================================
# API ROUTES
# ============================================================

ui.expose_api(
    "POST",
    "/api/message",
    genera_risposta_cyberdeck
)

ui.expose_api(
    "POST",
    "/api/system",
    get_system_status
)

ui.expose_api(
    "POST",
    "/api/sensors",
    get_sensors
)

ui.expose_api(
    "POST",
    "/api/gpio",
    gpio_command
)

ui.expose_api(
    "POST",
    "/api/network",
    get_network_status
)

ui.expose_api(
    "POST",
    "/api/terminal",
    terminal_command
)

ui.expose_api(
    "POST",
    "/api/shutdown",
    spegni_sistema
)

ui.expose_api("POST", "/api/buzzer", buzzer_command)


# ============================================================
# START
# ============================================================

print(
    "\n"
    "=======================================================\n"
    "       DREAMDECK API SERVER\n"
    "       Arduino UNO Q / Port 7000\n"
    "=======================================================\n"
)

print(
    "[INFO] Waiting for MCU Bridge..."
)


try:

    Bridge.call(
        "ai_isactive",
        True
    )

except Exception as e:

    print(
        f"[WARNING] Could not activate AI state: {e}"
    )


App.run()