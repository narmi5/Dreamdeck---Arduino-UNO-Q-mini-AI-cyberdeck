#include "Arduino_LED_Matrix.h"
#include <Arduino_RouterBridge.h>
#include <DHT.h>

#define DHTPIN A0
#define DHTTYPE DHT11
#define BUZZER_PIN 3

DHT dht(
  DHTPIN,
  DHTTYPE
);

Arduino_LED_Matrix matrix;

bool ai_active = false;


// ============================================================
// ANIMATIONS
// ============================================================

namespace Ui {

  const unsigned long FRAME_DELAY_MS =
    2000UL;

  const unsigned long FRAME_DELAY_MS2 =
    250UL;
}


// ============================================================
// HEART SMALL
// ============================================================

const uint8_t kHeartSmall[8][13] = {

  {0,0,0,0,0,0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0,0,0,0,0,0},

  {0,0,0,0,1,0,0,0,1,0,0,0,0},

  {0,0,0,1,1,1,0,1,1,1,0,0,0},

  {0,0,0,0,1,1,1,1,1,0,0,0,0},

  {0,0,0,0,0,1,1,1,0,0,0,0,0},

  {0,0,0,0,0,0,1,0,0,0,0,0,0},

  {0,0,0,0,0,0,0,0,0,0,0,0,0}
};


// ============================================================
// HEART MEDIUM
// ============================================================

const uint8_t kHeartMedium[8][13] = {

  {0,0,0,0,0,0,0,0,0,0,0,0,0},

  {0,0,0,1,1,0,0,0,1,1,0,0,0},

  {0,0,1,1,1,1,0,1,1,1,1,0,0},

  {0,0,1,1,1,1,1,1,1,1,1,0,0},

  {0,0,0,1,1,1,1,1,1,1,0,0,0},

  {0,0,0,0,1,1,1,1,1,0,0,0,0},

  {0,0,0,0,0,1,1,1,0,0,0,0,0},

  {0,0,0,0,0,0,1,0,0,0,0,0,0}
};


// ============================================================
// SENSOR FUNCTIONS
// ============================================================

int get_temperature() {

  float t =
    dht.readTemperature();

  if (isnan(t)) {

    return -999;
  }

  return (int)t;
}


int get_humidity() {

  float h =
    dht.readHumidity();

  if (isnan(h)) {

    return -999;
  }

  return (int)h;
}

// ============================================================
// BUZZER
// ============================================================

void buzzer(int frequency, int duration) {

  if (frequency <= 0) {
    noTone(BUZZER_PIN);
    return;
  }

  tone(
    BUZZER_PIN,
    frequency,
    duration
  );
}
// ============================================================
// LED
// ============================================================

void led(bool value) {

  // Built-in LED is active LOW
  digitalWrite(
    LED_BUILTIN,
    value ? LOW : HIGH
  );
}


// ============================================================
// AI STATE
// ============================================================

void ai_isactive(
  bool value
) {

  ai_active = value;
}


// ============================================================
// LED MATRIX
// ============================================================

void showBitmap(
  const uint8_t bitmap[8][13]
) {

  uint32_t frame[4] = {};

  Arduino_LED_Matrix::loadPixelsToBuffer(
    (uint8_t *)&bitmap[0][0],
    sizeof(kHeartSmall),
    frame
  );

  matrix.loadFrame(
    frame
  );
}


// ============================================================
// SETUP
// ============================================================

void setup() {

  pinMode(
    LED_BUILTIN,
    OUTPUT
  );

  pinMode(
    BUZZER_PIN,
    OUTPUT
  );

  digitalWrite(
    LED_BUILTIN,
    HIGH
  );
  Monitor.begin();
  Bridge.begin();

  Bridge.provide(
    "ai_isactive",
    ai_isactive
  );

  Bridge.provide(
    "get_temperature",
    get_temperature
  );

  Bridge.provide(
    "get_humidity",
    get_humidity
  );

  Bridge.provide(
    "led",
    led
  );

  Bridge.provide("buzzer", buzzer);

  dht.begin();

  matrix.begin();

  matrix.clear();
}


// ============================================================
// LOOP
// ============================================================

void loop() {

  Bridge.update();

  static unsigned long lastFrame = 0;
  static bool heartMedium = false;

  unsigned long now = millis();

  if (ai_active) {

    unsigned long interval =
      heartMedium
        ? Ui::FRAME_DELAY_MS2
        : Ui::FRAME_DELAY_MS;

    if (now - lastFrame >= interval) {

      lastFrame = now;

      heartMedium = !heartMedium;

      if (heartMedium) {
        showBitmap(kHeartMedium);
      } else {
        showBitmap(kHeartSmall);
      }
    }

  } else {

    matrix.clear();
  }
}