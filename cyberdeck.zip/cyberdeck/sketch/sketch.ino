#include "Arduino_LED_Matrix.h"
#include <Arduino_RouterBridge.h>
#include <DHT.h>

#define DHTPIN A0
#define DHTTYPE DHT11
#define BUZZER_PIN 3

DHT dht(DHTPIN, DHTTYPE);
Arduino_LED_Matrix matrix;

bool ai_active = false;

namespace Ui {
  const unsigned long FRAME_DELAY_MS = 2000UL;
  const unsigned long FRAME_DELAY_MS2 = 250UL;
}

// ============================================================
// HEART SMALL
// ============================================================

const uint8_t kHeartSmall[8][13] = {
  {0,0,0,0,0,0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0,0,0,0,0,0},
  {0,0,0,0,1,0,0,0,1,0,0,0,0},
  {0,0,0,1,1,1,0,1,1,1,0,0,0},
  {0,0,0,0,1,1,1,1,1,0,0,0,0},
  {0,0,0,0,0,1,1,1,0,0,0,0,0},
  {0,0,0,0,0,0,1,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0,0,0,0,0,0}
};

// ============================================================
// HEART MEDIUM
// ============================================================

const uint8_t kHeartMedium[8][13] = {
  {0,0,0,0,0,0,0,0,0,0,0,0,0},
  {0,0,0,1,1,0,0,0,1,1,0,0,0},
  {0,0,1,1,1,1,0,1,1,1,1,0,0},
  {0,0,1,1,1,1,1,1,1,1,1,0,0},
  {0,0,0,1,1,1,1,1,1,1,0,0,0},
  {0,0,0,0,1,1,1,1,1,0,0,0,0},
  {0,0,0,0,0,1,1,1,0,0,0,0,0},
  {0,0,0,0,0,0,1,0,0,0,0,0,0}
};

// ============================================================
// FUNCTIONS
// ============================================================

int get_temperature() {
  float t = dht.readTemperature();

  if (isnan(t)) {
    return -999;
  }

  return (int)t;
}

int get_humidity() {
  float h = dht.readHumidity();

  if (isnan(h)) {
    return -999;
  }

  return (int)h;
}

void buzzer(int frequency, int duration) {
  if (frequency <= 0) {
    noTone(BUZZER_PIN);
    return;
  }

  tone(BUZZER_PIN, frequency, duration);
}

void led(bool value) {
  digitalWrite(LED_BUILTIN, value ? LOW : HIGH);
}



// ============================================================
// GENERIC GPIO
// ============================================================

int resolvePin(int pin) {

  switch (pin) {

    case 101:
      return A1;

    case 102:
      return A2;

    case 103:
      return A3;

    case 104:
      return A4;

    case 105:
      return A5;

    default:
      return pin;
  }
}


// ============================================================
// DIGITAL READ
// ============================================================

int gpio_digital_read(int pin) {

  pin = resolvePin(pin);

  // Only real digital header pins
  if (pin < 2 || pin > 13) {
    return -1;
  }

  pinMode(
    pin,
    INPUT
  );

  return digitalRead(
    pin
  );
}


// ============================================================
// DIGITAL WRITE
// ============================================================
// IMPORTANT:
// int instead of bool.
// Python sends 0 or 1.
// Function returns the actual digitalRead state after writing.
// ============================================================

int gpio_digital_write(
  int pin,
  int value
) {

  pin = resolvePin(pin);

  if (pin < 2 || pin > 13) {
    return -1;
  }

  pinMode(
    pin,
    OUTPUT
  );

  digitalWrite(
    pin,
    value != 0
      ? HIGH
      : LOW
  );

  // Read back the pin so Python knows the operation happened.
  return digitalRead(
    pin
  );
}


// ============================================================
// ANALOG READ
// ============================================================

int gpio_analog_read(int pin) {

  pin = resolvePin(pin);

  if (pin < A1 || pin > A5) {
    return -1;
  }

  pinMode(
    pin,
    INPUT
  );

  return analogRead(
    pin
  );
}


// ============================================================
// ANALOG / PWM WRITE
// ============================================================

int gpio_analog_write(
  int pin,
  int value
) {

  pin = resolvePin(pin);

  value = constrain(
    value,
    0,
    255
  );

  // IMPORTANT:
  // Do NOT call pinMode() before analogWrite().
  // On the UNO Q, analogWrite() configures the PWM pin itself.
  analogWrite(
    pin,
    value
  );

  return value;
}

//GPIO

void ai_isactive(bool value) {
  ai_active = value;
}

void showBitmap(const uint8_t bitmap[8][13]) {
  uint32_t frame[4] = {};

  Arduino_LED_Matrix::loadPixelsToBuffer(
    (uint8_t *)&bitmap[0][0],
    sizeof(kHeartSmall),
    frame
  );

  matrix.loadFrame(frame);
}

// ============================================================
// SETUP
// ============================================================

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(LED_BUILTIN, HIGH);

  Monitor.begin();
  Bridge.begin();

  Bridge.provide("ai_isactive", ai_isactive);
  Bridge.provide("get_temperature", get_temperature);
  Bridge.provide("get_humidity", get_humidity);
  Bridge.provide("led", led);
  Bridge.provide("buzzer", buzzer);
  
  Bridge.provide_safe(
    "gpio_digital_read",
    gpio_digital_read
  );
  
  Bridge.provide_safe(
    "gpio_digital_write",
    gpio_digital_write
  );
  
  Bridge.provide_safe(
    "gpio_analog_read",
    gpio_analog_read
  );
  
  Bridge.provide_safe(
    "gpio_analog_write",
    gpio_analog_write
  );

  dht.begin();

  matrix.begin();
  matrix.clear();
}

// ============================================================
// LOOP
// ============================================================

void loop() {

  Bridge.update();

  static unsigned long lastFrame = 0;
  static bool heartMedium = false;

  unsigned long now = millis();

  if (ai_active) {

    unsigned long interval =
      heartMedium
        ? Ui::FRAME_DELAY_MS2
        : Ui::FRAME_DELAY_MS;

    if (now - lastFrame >= interval) {

      lastFrame = now;

      heartMedium = !heartMedium;

      if (heartMedium) {
        showBitmap(kHeartMedium);
      } else {
        showBitmap(kHeartSmall);
      }
    }

  } else {

    matrix.clear();
  }
}