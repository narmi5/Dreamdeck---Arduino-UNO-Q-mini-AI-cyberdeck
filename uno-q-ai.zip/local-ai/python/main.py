# SPDX-License-Identifier: MPL-2.0
import os
import re
import time
from typing import Any
from arduino.app_bricks.llm import LargeLanguageModel
from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import *
from prompts import load_system_prompt

print("[INFO] Initializing local AI (Brick LLM)...")
llm = LargeLanguageModel(system_prompt=load_system_prompt())

MAX_PAIRS = 2
chat_history: list[dict[str, str]] = []

def build_context_prompt(user_input: str) -> str:
    if not chat_history:
        return f"User: {user_input}\nAI:"
        
    context_lines = ["Conversation history:"]
    for msg in chat_history:
        if msg["role"] == "user":
            context_lines.append(f"User: {msg['content']}")
        else:
            context_lines.append(f"AI: {msg['content']}")
            
    context_lines.append(f"User: {user_input}\nAI:")
    return "\n".join(context_lines)

def clean_response(text: str, user_prompt: str) -> str:
    text = text.strip()

    escaped_prompt = re.escape(user_prompt)
    text = re.sub(rf'^(?:User:)?\s*{escaped_prompt}[\s\?\!:\.]*', '', text, flags=re.IGNORECASE).strip()

    text = re.sub(r'^(AI|Assistant|Model|Response|Gemma):\s*', '', text, flags=re.IGNORECASE)

    text = re.split(r'\n?(?:User|User asked|AI|Assistant):', text, flags=re.IGNORECASE)[0]
    
    return text.replace("\n", " ").strip()

ui = WebUI()

def genera_risposta_cyberdeck(data: dict[str, Any]) -> dict[str, str]:
    global chat_history
    try:
        prompt = data.get("prompt", "")
        if prompt:
            print(f"\n[HTTP API] Prompt: {prompt}")
            
            full_prompt = build_context_prompt(prompt)

            risposta_raw = ""
            for resp in llm.chat_stream(full_prompt):
                risposta_raw += resp
                
            risposta_pulita = clean_response(risposta_raw, prompt)
            print(f"[AI LOCAL]: {risposta_pulita}")

            chat_history.append({"role": "user", "content": prompt})
            chat_history.append({"role": "assistant", "content": risposta_pulita})
            
            if len(chat_history) > (MAX_PAIRS * 2):
                chat_history = chat_history[-(MAX_PAIRS * 2):]

            return {"text": risposta_pulita}
        return {"text": "Empty prompt"}
    except Exception as e:
        print(f"[ERROR]: {e}")
        return {"text": f"Internal error: {str(e)}"}

def spegni_sistema(data: dict[str, Any]) -> dict[str, str]:
    Bridge.call("ai_isactive", False)
    print("[SYSTEM] Shutdown command issued")
    os.system("sudo shutdown -h now")
    return {"text": "Shutting down app"}

ui.expose_api("POST", "/api/message", genera_risposta_cyberdeck)
ui.expose_api("POST", "/api/shutdown", spegni_sistema)

print("\n=======================================================")
print(" ARDUINO UNO Q: HTTP SERVER API READY ON PORT 7000")
print("=======================================================\n")

Bridge.call("ai_isactive", True)

print("[INFO] Waiting for MCU Bridge connection...")

App.run()