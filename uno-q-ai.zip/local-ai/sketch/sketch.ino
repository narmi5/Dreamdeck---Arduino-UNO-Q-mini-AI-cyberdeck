#include "Arduino_LED_Matrix.h"
#include <Arduino_RouterBridge.h>

Arduino_LED_Matrix matrix;
bool ai_active = false;
namespace Ui {
const unsigned long FRAME_DELAY_MS = 2000UL;
  const unsigned long FRAME_DELAY_MS2 = 250UL;
}

const uint8_t kHeartSmall[8][13] = {
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0},
    {0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0},
    {0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
};

const uint8_t kHeartMedium[8][13] = {
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0},
    {0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0},
    {0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
    {0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0},
    {0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0},
};


void showBitmap(const uint8_t bitmap[8][13]) {
  uint32_t frame[4] = {};
  Arduino_LED_Matrix::loadPixelsToBuffer((uint8_t *)&bitmap[0][0], sizeof(kHeartSmall), frame);
  matrix.loadFrame(frame);
}

void ai_isactive(bool value) {
  ai_active = value;
}

void setup() {
  Bridge.begin();
  Bridge.provide("ai_isactive", ai_isactive);
  matrix.begin();
  matrix.clear();
}

void loop() {
  Bridge.update();
  if(ai_active){
    showBitmap(kHeartSmall);
    delay(Ui::FRAME_DELAY_MS);
  
    showBitmap(kHeartMedium);
    delay(Ui::FRAME_DELAY_MS2);
  }
}